#include "TP2_1.h"
#include <cmath>
#include <random>

// Méthode de Box-Muller pour générer une valeur gaussienne
double generateGaussian(double moyenne, double ecartType, std::mt19937& gen) {
    std::uniform_real_distribution<> dis(0.0, 1.0);

    double u1 = dis(gen);
    double u2 = dis(gen);

    double z0 = std::sqrt(-2.0 * std::log(u1)) * std::cos(2.0 * M_PI * u2);
    return z0 * ecartType + moyenne;
}

// Génère une série temporelle gaussienne
vector<double> GaussianGenerator::generateTimeSeries(int n) {
    std::mt19937 gen(seed);  // Initialisation avec la graine
    vector<double> series;

    for (int i = 0; i < n; ++i) {
        series.push_back(generateGaussian(moyenne, ecartType, gen));
    }

    return series;
}

// Affiche une série temporelle
void TimeSeriesGenerator::printTimeSeries(const vector<double>& series) {
    for (double value : series) {
        cout << value << " ";
    }
    cout << endl;
}

vector<double> StepGenerator::generateSteps(int n) {
    vector<double> steps;
    steps.push_back(0);  // La première valeur est 0

    std::random_device rd;
    std::mt19937 gen(seed);  // Utilise la graine de la classe de base
    std::uniform_int_distribution<> valueDist(0, 100); // Pour les valeurs entre 0 et 100
    std::uniform_real_distribution<> probDist(0.0, 1.0); // Pour la probabilité de 50%

    for (int i = 1; i < n; ++i) {
        double prob = probDist(gen);
        
        if (prob < 0.5) {
            // Choisir une nouvelle valeur entre 0 et 100
            steps.push_back(valueDist(gen));
        } else {
            // Garder la valeur précédente
            steps.push_back(steps[i - 1]);
        }
    }

    return steps;
}

vector<double> SinWaveGenerator::generateSinus(int n, double a, double w, double p) {
    vector<double> sin;
    sin.reserve(n); // Optimisation pour éviter les reallocations

    for (int i = 0; i < n; i++) {
        double x = i;  // Par défaut, on utilise i comme valeur x pour chaque point
        double value = a * std::sin(w * x + p);  // Calcul de f(x) = A * sin(ω * x + ϕ)
        sin.push_back(value); // Ajoute la valeur calculée au vecteur
    }

    return sin;
}
