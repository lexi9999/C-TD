#ifndef TP2_1_H
#define TP2_1_H

#include <string>
#include <iostream>
#include <vector>
#include <random>

using namespace std;

class TimeSeriesGenerator {
public:
    TimeSeriesGenerator(int s) : seed(s) {};
    TimeSeriesGenerator() : seed(0) {};

    vector<double> generateTimeSeries(int);
    void printTimeSeries(const vector<double>&);

    int seed;
};

class GaussianGenerator : public TimeSeriesGenerator {
public:
    GaussianGenerator(double m, double e, int s = 0) : TimeSeriesGenerator(s), moyenne(m), ecartType(e) {}

    vector<double> generateTimeSeries(int n);

private:
    double moyenne;
    double ecartType;
};

class StepGenerator : public TimeSeriesGenerator {
public:
    StepGenerator(int s = 0) : TimeSeriesGenerator(s) {}

    vector<double> generateSteps(int n);
};


class SinWaveGenerator : public TimeSeriesGenerator {
public:
    SinWaveGenerator(int s = 0) : TimeSeriesGenerator(s) {}

    vector<double> generateSinus(int n, double a, double w, double p);
};

#endif
