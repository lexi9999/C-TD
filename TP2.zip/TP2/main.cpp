#include "TP2_1.h"

int main() {
    SinWaveGenerator sinGen(42); // Crée une instance avec une graine
    double amplitude = 1.0;
    double frequency = 0.1;
    double phase = 0.0;

    vector<double> sinusSeries = sinGen.generateSinus(10, amplitude, frequency, phase);
    sinGen.printTimeSeries(sinusSeries);

    return 0;
}
