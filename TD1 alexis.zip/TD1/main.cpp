#include<stdio.h>
#include<stdlib.h>
#include <iostream>  // Pour std::cout et std::cin
#include <string>    // Pour std::string
#include <cmath> 

#include "printer.h"

class MyClass{

public:
    MyClass(std::string e1) : element(e1){};

    void print_my_element(){
        std::cout << "Voici l'element: " << element << std::endl;
    };
private:
    std::string element;
};

class Complex2D{

public:
    Complex2D() : re(0), im(0){};
    Complex2D(double re1, double im1) : re(re1), im(im1){};
    Complex2D(double all) : re(all), im(all){};
    Complex2D(Complex2D& comp) : re(comp.getRe()), im(comp.getIm()){};

    void show(){
        std::cout << "Here : " << re << " + " << im << "i" << std::endl;
    };

    double getRe(){
        return(re);
    }
    double getIm(){
        return(im);
    } 
    void setRe(double n){
        re = n;
    }
    void setIm(double n){
        im = n;
    } 

    friend Complex2D operator+(Complex2D c1, Complex2D c2){
        return Complex2D(c1.getRe() + c2.getRe(), c1.getIm() + c2.getIm());
    }

    friend Complex2D operator-(Complex2D c1, Complex2D c2){
        return Complex2D(c1.getRe() - c2.getRe(), c1.getIm() - c2.getIm());
    }

    friend Complex2D operator*(Complex2D c1, Complex2D c2){
        return Complex2D(c1.getRe() * c2.getRe() - c1.getIm()*c2.getIm(), c1.getIm()*c2.getRe() + c1.getRe() * c2.getIm());
    }

    friend Complex2D operator/(Complex2D c1, Complex2D c2){
        return Complex2D( (((c1*c2).conj()).getRe())/(c1*c2).mod() , (((c1*c2).conj()).getIm())/(c1*c2).mod() );
    }

    friend bool operator<(Complex2D c1, Complex2D c2) {
        bool result = c1.mod() < c2.mod();
        std::cout << (result ? "true" : "false") << std::endl;
        return result;
    }

    friend bool operator>(Complex2D c1, Complex2D c2) {
        bool result = c1.mod() > c2.mod();
        std::cout << (result ? "true" : "false") << std::endl;
        return result;
    }

    Complex2D conj(){
        return Complex2D(re, -im);
    }
    double mod(){
        return sqrt((re*re) + (im*im));
    }

private:
    double re;
    double im;
};


int main(){
    printer("Alexis");

    MyClass test("Element de test\n");
    test.print_my_element();

    Complex2D c1;
    Complex2D c2(2, 4);
    Complex2D c3(10);
    Complex2D c4(c3);

    c1.show();
    c2.show();
    c3.show();
    c4.show();

    /*
    c4.setIm(99);
    c4.show();
    c4.setRe(88);
    c4.show();

    c1 = c3 + c3;
    c1.show();
    c2 = c1 - c2;
    c2.show();

    Complex2D c5(2, 2);
    c2 = c5 * c5;
    c2.show();
    

    c4 = c2 / c3;
    c4.show();
    c3 < c2;
    c2 < c3;

    c3 > c2;
    c2 > c3;
    */

    return 0;
}

//On peut ajouter une fonction qui donne la distance algébrique entre 2 complexes