// printer.h
#ifndef PRINTER_H
#define PRINTER_H

#include <string>  // Pour std::string

// Déclaration de la fonction printer
void printer(std::string nom);

#endif
