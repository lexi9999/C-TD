// printer.cpp
#include <iostream>
#include "printer.h"

// Implémentation de la fonction printer
void printer(std::string nom) {
    std::cout << "Bonjour, " << nom << "!\n" << std::endl;
}
