#include "TD4_1.h"
#include <iostream>

// Définition du constructeur de Card
Card::Card(std::string s) : cardName(s) {}

void Card::showName() const {
    std::cout << "Card Name: " << cardName << std::endl;
}

// Définition de PokemonCard
PokemonCard::PokemonCard(std::string name, std::string type, std::string family, int level, int maxHealth, 
                         int Ecost1, std::string descAtt1, int DPS1, 
                         int Ecost2, std::string descAtt2, int DPS2)
    : Card(name), pokemonType(type), familyName(family), evolutionLevel(level), maxHP(maxHealth), hp(maxHealth) {
    attacks.push_back(std::make_tuple(Ecost1, Ecost1, descAtt1, DPS1));
    attacks.push_back(std::make_tuple(Ecost2, Ecost2, descAtt2, DPS2));
}

void PokemonCard::displayInfo() const {
    showName();
    std::cout << "Type: " << pokemonType << "\nFamily: " << familyName 
              << "\nEvolution Level: " << evolutionLevel 
              << "\nMax Health: " << maxHP 
              << "\nCurrent Health: " << hp 
              << "\nAttached Energy: " << attachedEnergy << std::endl;

    for (const auto& attack : attacks) {
        std::cout << "Attack - Cost: " << std::get<0>(attack) 
                  << ", Description: " << std::get<2>(attack) 
                  << ", Damage: " << std::get<3>(attack) << std::endl;
    }
}

void PokemonCard::attachEnergy() {
    attachedEnergy++;
}

void PokemonCard::takeDamage(int damage) {
    hp -= damage;
    if (hp < 0) hp = 0;
}

// Définition de EnergyCard
EnergyCard::EnergyCard(std::string typeE) 
    : Card("Energy"), energyType(typeE) {}

void EnergyCard::displayInfo() const {
    std::cout << "Energy Type: " << energyType << std::endl;
}

// Définition de TrainerCard
TrainerCard::TrainerCard(std::string name, std::string trainerEff) 
    : Card(name), trainerEffect(trainerEff) {}

void TrainerCard::displayInfo() const {
    std::cout << "Trainer Effect: " << trainerEffect << std::endl;
}

void TrainerCard::use() {
    std::cout << "Using Trainer Card: " << trainerEffect << std::endl;
}

// Définition de Player
void Player::addCardToBench(Card* c) {
    benchCards.push_back(c);
}

void Player::activatePokemonCard(int index) {
    if (index < benchCards.size()) {
        activePokemon = dynamic_cast<PokemonCard*>(benchCards[index]);
        if (activePokemon) {
            std::cout << playerName << " activated Pokemon: ";
            activePokemon->displayInfo();
        }
    }
}

void Player::attachEnergyCard(int energyIndex, int pokemonIndex) {
    if (energyIndex < benchCards.size() && pokemonIndex < benchCards.size()) {
        auto energyCard = dynamic_cast<EnergyCard*>(benchCards[energyIndex]);
        auto pokemonCard = dynamic_cast<PokemonCard*>(benchCards[pokemonIndex]);
        if (energyCard && pokemonCard) {
            pokemonCard->attachEnergy();
            std::cout << "Attached energy to " << pokemonCard->cardName << std::endl;
        }
    }
}


void Player::displayBench() const {
    for (const auto& card : benchCards) {
        card->displayInfo();
    }
}

void Player::displayAction() const {
    if (activePokemon) {
        std::cout << "Active Pokemon: " << std::endl;
        activePokemon->displayInfo();
    } else {
        std::cout << "No active Pokemon" << std::endl;
    }
}

void Player::attack(int attackerIndex, int attackIndex, Player& opponent, int defenderIndex) {
    if (activePokemon && defenderIndex < opponent.benchCards.size()) {
        auto attack = activePokemon->attacks[attackIndex];
        int damage = std::get<3>(attack);
        auto opponentPokemon = dynamic_cast<PokemonCard*>(opponent.benchCards[defenderIndex]);
        if (opponentPokemon) {
            opponentPokemon->takeDamage(damage);
            std::cout << playerName << " attacked " << opponent.playerName << "'s Pokemon for " << damage << " damage!" << std::endl;
        }
    }
}

void Player::useTrainer(int index) {
    if (index < benchCards.size()) {
        auto trainerCard = dynamic_cast<TrainerCard*>(benchCards[index]);
        if (trainerCard) {
            trainerCard->use();
            if (activePokemon) activePokemon->takeDamage(-10); // Exemple d'effet de guérison
        }
    }
}

Player::~Player() {
    for (Card* card : benchCards) {
        delete card;
    }
}
