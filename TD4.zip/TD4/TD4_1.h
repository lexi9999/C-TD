#ifndef TD4_1_H
#define TD4_1_H

#include <iostream>
#include <string>
#include <vector>
#include <tuple>

class Card {
protected:
    std::string cardName;

public:
    Card(std::string s);
    virtual ~Card() = default; // Destructeur virtuel pour éviter les fuites mémoire
    void showName() const;
    virtual void displayInfo() const = 0;  // Méthode virtuelle pure
};

class PokemonCard : public Card {
protected:
    std::string pokemonType;
    std::string familyName;
    int evolutionLevel;
    int maxHP;
    int hp;
    std::vector<std::tuple<int, int, std::string, int>> attacks;
    int attachedEnergy = 0;

public:
    PokemonCard(std::string name, std::string type, std::string family, int level, int maxHealth,
                int Ecost1, std::string descAtt1, int Dps1, int Ecost2, std::string descAtt2, int Dps2);

    void displayInfo() const override;
    void attachEnergy(); // Attache une énergie
    void takeDamage(int damage); // Reçoit des dégâts
};

class EnergyCard : public Card {
protected:
    std::string energyType; 
public:
    EnergyCard(std::string typeE);
    void displayInfo() const override; // Affichage spécifique pour EnergyCard
};

class TrainerCard : public Card {
protected:
    std::string trainerEffect; 
public:
    TrainerCard(std::string name, std::string trainerEff);
    void displayInfo() const override; // Affichage spécifique pour TrainerCard
    void use(); // Applique l'effet de la carte entraîneur
};

class Player {
protected:
    std::string playerName;
    std::vector<Card*> benchCards;
    PokemonCard* activePokemon = nullptr; // Pokémon actif

public:
    Player(std::string name) : playerName(name) {}
    ~Player();  // Déclaration du destructeur
    void addCardToBench(Card* c);
    void activatePokemonCard(int index); // Active un Pokémon
    void attachEnergyCard(int energyIndex, int pokemonIndex); // Attache une carte énergie
    void displayBench() const; // Affiche le banc
    void displayAction() const; // Affiche le Pokémon actif
    void attack(int attackerIndex, int attackIndex, Player& opponent, int defenderIndex); // Attaque un autre joueur
    void useTrainer(int index); // Utilise une carte d'entraîneur
};

#endif
