#include <iostream>
#include <vector>

using namespace std;

template <typename T>
class MatrixBase {
public:
    // Constructeurs
    MatrixBase() : rows(0), cols(0) {}

    MatrixBase(size_t r, size_t c) : rows(r), cols(c) {
        data.resize(rows, vector<T>(cols));
    }

    // Affichage de la matrice
    void Display() {
        for (size_t i = 0; i < rows; i++) {
            std::cout << std::endl; 
            for (size_t j = 0; j < cols; j++) {
                std::cout << data[i][j] << " ";
            }
        }
        std::cout << std::endl;
    }

    // Ajouter un élément
    void addElement(size_t rowIndex, size_t colIndex, T el) {
        if (rowIndex < rows && colIndex < cols) {
            data[rowIndex][colIndex] = el;
        } else {
            std::cout << "Index hors limites !" << std::endl;
        }
    }

    // Obtenir un élément
    T getElement(size_t rowIndex, size_t colIndex) {
        if (rowIndex < rows && colIndex < cols) {
            return data[rowIndex][colIndex];
        } else {
            std::cerr << "Index hors limites !" << std::endl;
            return T();  // Retourne la valeur par défaut du type T en cas d'erreur
        }
    }

    // Obtenir le nombre de lignes
    size_t getRows() const {
        return rows;
    }

    // Obtenir le nombre de colonnes
    size_t getCols() const {
        return cols;
    }

protected:
    vector<vector<T>> data;  // Vecteur 2D pour stocker les éléments
    size_t rows;  // Nombre de lignes
    size_t cols;  // Nombre de colonnes
};

// Exemple d'utilisation
int main() {
    MatrixBase<int> matrix(3, 3);

    matrix.addElement(0, 0, 1);
    matrix.addElement(1, 1, 2);
    matrix.addElement(2, 2, 3);

    matrix.Display();  // Affichage de la matrice

    std::cout << "Element à [1, 1] : " << matrix.getElement(1, 1) << std::endl;
    std::cout << "Nombre de lignes: " << matrix.getRows() << std::endl;
    std::cout << "Nombre de colonnes: " << matrix.getCols() << std::endl;

    return 0;
}
