#include <iostream>
#include <vector>

class SearchingAlgorithm {

public:
    // Constructeur par défaut
    SearchingAlgorithm() : numberComparisons(0) {};

    // Fonction virtuelle pure pour la recherche
    virtual int search(std::vector<int> vec, int goal) = 0;

    // Affiche les résultats de la recherche
    virtual int displaySearchResults(std::ostream& os, int results, int target) const {
        totalSearch++;
        if (results == -1) {
            os << "Searching for the element " << target << " was not successful." << std::endl;
        } else {
            totalComparisons += numberComparisons;
            averageComparisons = static_cast<double>(totalComparisons) / totalSearch;
            os << "It took a total of " << numberComparisons << " comparisons to find the element at index " 
               << results << "." << std::endl;
        }
        os << "Total Comparisons: " << totalComparisons << std::endl;
        os << "Average Comparisons: " << averageComparisons << std::endl;
        return results;
    }

    void show() {
        std::cout << "Comparisons made: " << numberComparisons << std::endl;
    }

    // Attributs
    int numberComparisons;  // Comparaisons pour une recherche

    // Variables statiques
    static int totalComparisons;  // Total des comparaisons
    static int totalSearch;       // Total des recherches
    static double averageComparisons;  // Moyenne des comparaisons

};

// Initialisation des membres statiques
int SearchingAlgorithm::totalComparisons = 0;
int SearchingAlgorithm::totalSearch = 0;
double SearchingAlgorithm::averageComparisons = 0.0;


class LinearSearch : public SearchingAlgorithm {
public:
    // Implémentation de la recherche linéaire
    int search(std::vector<int> vec, int goal) override {
        numberComparisons = 0;
        for (int i = 0; i < vec.size(); i++) {
            numberComparisons++;
            if (vec[i] == goal) {
                return i;
            }
        }
        return -1; // élément non trouvé
    }
};


#include <cmath>


class JumpSearch : public SearchingAlgorithm {
public:
    // Implémentation de la recherche par sauts
    int search(std::vector<int> vec, int goal) override {
        numberComparisons = 0;
        int n = vec.size();
        int step = sqrt(n); // Taille du saut
        int prev = 0;

        // Trouver le bloc contenant l'élément
        while (vec[std::min(step, n) - 1] < goal) {
            numberComparisons++;
            prev = step;
            step += sqrt(n);
            if (prev >= n)
                return -1; // élément non trouvé
        }

        // Recherche linéaire dans le bloc trouvé
        for (int i = prev; i < std::min(step, n); i++) {
            numberComparisons++;
            if (vec[i] == goal) {
                return i;
            }
        }

        return -1; // élément non trouvé
    }
};


class BinarySearch : public SearchingAlgorithm {
public:
    // Implémentation de la recherche binaire
    int search(std::vector<int> vec, int goal) override {
        numberComparisons = 0;
        int left = 0, right = vec.size() - 1;

        while (left <= right) {
            numberComparisons++;
            int mid = left + (right - left) / 2;

            if (vec[mid] == goal)
                return mid;
            else if (vec[mid] < goal)
                left = mid + 1;
            else
                right = mid - 1;
        }

        return -1; // élément non trouvé
    }
};


int main() {
    std::vector<int> data = {1, 3, 5, 7, 9, 11, 13, 15}; // Liste triée
    int target = 7;

    LinearSearch ls;
    int result = ls.search(data, target);
    ls.displaySearchResults(std::cout, result, target);

    JumpSearch js;
    result = js.search(data, target);
    js.displaySearchResults(std::cout, result, target);

    BinarySearch bs;
    result = bs.search(data, target);
    bs.displaySearchResults(std::cout, result, target);

    return 0;
}
