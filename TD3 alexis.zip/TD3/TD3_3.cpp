#include <iostream>
#include <queue>
#include <stack>
#include <cctype>

using namespace std;

bool isPalindrome(const string& input) {
    stack<char> s;
    queue<char> q;

    // Remplir la stack et la queue avec les caractères
    for (char c : input) {
        // Ignorer les caractères non alphabétiques et convertir en minuscule
        if (isalpha(c)) {
            char lowerChar = tolower(c);
            s.push(lowerChar);
            q.push(lowerChar);
        }
    }

    // Comparer les éléments de la stack et de la queue
    while (!s.empty() && !q.empty()) {
        if (s.top() != q.front()) {
            return false; // Ce n'est pas un palindrome
        }
        s.pop();
        q.pop();
    }

    return true; // C'est un palindrome
}

int main() {
    cout << boolalpha;

    cout << "Is 'racecar' a palindrome? " 
         << isPalindrome("racecar") << endl;

    cout << "Is 'hello' a palindrome? " 
         << isPalindrome("hello") << endl;

    return 0;
}
