#include <iostream>
#include <vector>
#include <map>

using namespace std;

void countFrequencyBruteForce(const vector<int>& numbers) {
    // Votre code
    for (int i = 0; i < numbers.size(); i++) {
        int compt = 0;  // Ajout du point-virgule
        for (int j = 0; j < numbers.size(); j++) {
            if (numbers[i] == numbers[j]) {  // Remplacer `vector` par `numbers`
                compt++;
            }
        }
        cout << "Occurrence de \"" << numbers[i] << "\" dans le vector : " << compt << " fois" << endl;
    }
}

map<int, int> countFrequencyOptimal(const vector<int>& numbers) {
    // Votre code (vide pour l'instant)
    map<int, int> myMap;
    for(int i=0; i<numbers.size(); i++){
        int compt = 0;
        for(int j=0; j<numbers.size(); j++){
            if(numbers[i] == numbers[j]){
                compt++;
            }
        }
        myMap.insert(std::make_pair(numbers[i], compt));
    }

    return myMap;
}

int main() {
    vector<int> numbers = { 1, 2, 3, 2, 4, 1, 5, 5, 6 };

    // Test countFrequencyBruteForce
    cout << "Frequency (Brute Force) :" << endl;
    countFrequencyBruteForce(numbers);

    // Test countFrequencyOptimal
    cout << "\nFrequency (Optimal) :" << endl;  // Correction de l'espace après \n
    map<int, int> frequencyMapOptimal = countFrequencyOptimal(numbers);
    
    for (const auto& entry : frequencyMapOptimal) {
        cout << entry.first << " : " << entry.second << " times" << endl;  // Correction des guillemets
    }

    return 0;
}
