#include <iostream>
#include <vector>
#include <unordered_map>

using namespace std;

vector<int> twoSumBruteForce(const vector<int>& nums, int target) {
    // Implémentation brute force
    for (int i = 0; i < nums.size(); i++) {
        for (int j = i + 1; j < nums.size(); j++) {
            if (nums[i] + nums[j] == target) {
                return {i, j};  // Retourne les indices des deux nombres qui forment le target
            }
        }
    }
    return {};  // Retourne un vecteur vide si aucune solution n'est trouvée
}

vector<int> twoSumOptimal(const vector<int>& nums, int target) {
    // Implémentation optimale avec un unordered_map
    unordered_map<int, int> num_map;
    for (int i = 0; i < nums.size(); i++) {
        int complement = target - nums[i];
        if (num_map.find(complement) != num_map.end()) {
            return {num_map[complement], i};  // Retourne les indices de la solution optimale
        }
        num_map[nums[i]] = i;
    }
    return {};  // Retourne un vecteur vide si aucune solution n'est trouvée
}

int main() {
    vector<int> nums = {2, 7, 11, 15};
    int target = 9;

    vector<int> indicesBruteForce = twoSumBruteForce(nums, target);
    cout << "Brute Force Solution: ["
         << indicesBruteForce[0] << ", "
         << indicesBruteForce[1] << "]"
         << endl;

    vector<int> indicesOptimal = twoSumOptimal(nums, target);
    cout << "Optimal Solution: ["
         << indicesOptimal[0] << ", "
         << indicesOptimal[1] << "]"
         << endl;

    return 0;
}
